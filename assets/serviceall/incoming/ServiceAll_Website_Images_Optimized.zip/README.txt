These are original user-provided ServiceAll screenshots, resized to 780x1560 maximum and optimized to WebP with EXIF removed.

The connected GitHub repo now has an automated one-ZIP publishing workflow. The simplest way to publish is to upload the original Marketing Photos.zip into assets/serviceall/incoming/ on main. The workflow generates this folder automatically and updates serviceall.html.

If you prefer to upload assets manually, copy the files in assets/serviceall/screens-2026 to the same directory on GitHub, then update site references to screens-2026.
